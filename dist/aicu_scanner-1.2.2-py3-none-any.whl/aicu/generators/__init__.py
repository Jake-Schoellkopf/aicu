"""AICU file attack generators."""
